#!/usr/bin/env bash

# This is a fake install.sh meant to mimic an aspect of the ActivePython
# installer script. At the moment, all it wants to do is to fail with an
# exit code of 1.

>&2 echo -e "! failed to install"
exit 1

