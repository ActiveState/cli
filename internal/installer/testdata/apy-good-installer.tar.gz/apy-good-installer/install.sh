#!/usr/bin/env bash

# This is a fake install.sh meant to mimic an aspect of the ActivePython
# installer script. At the moment, all it wants to do is to write a file,
# in this case it happens to be an install.log, to an installation dir
# that is provided as the -I flag. This flag is the same that the
# ActivePython installer script support.

ts_fmt="%Y-%m-%dT%H:%M:%S%z"

function err() {
	echo -e "[$(date +"${ts_fmt}")]\t${1}" >> install.err.log
}

function die () {
	>&2 echo -e "! ${1}"
	exit 1
}

function log() {
	echo -e "[$(date +"${ts_fmt}")]\t${1}" >> install.log
}

install_dir=""

while getopts ":I:" opt; do
	case ${opt} in
	I ) # use an install dir
		install_dir=${OPTARG}
		;;
	\? )
		die "Usage: $0 -I <install-dir>"
		;;
	esac
done

if [[ "x${install_dir}x" = "xx" ]]; then
	die "install dir not defined"
elif [[ ! -d ${install_dir} ]]; then
	die "install dir '${install_dir}' not a directory"
fi

pushd ${install_dir}

log "successful install"

popd

